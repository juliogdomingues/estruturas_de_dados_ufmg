#ifndef TP2_ED_GRAFO_HPP
#define TP2_ED_GRAFO_HPP

#include "../include/item.hpp"
#include "../include/vetor.hpp"
#include <stdexcept>

class Grafo {
public:

    Grafo(int numeroVertices) : numeroVertices(numeroVertices), grafo(new Vetor[numeroVertices]), vertices(Vetor(numeroVertices)) {
        for (int i = 0; i < numeroVertices; i++) {
            vertices.push_back(Item(i)); 
        }        
    }

    ~Grafo() {
        // std::cout << "liberando array grafo " << grafo << std::endl;
        // delete[] grafo;  // Libera a memória alocada para o array grafo
        delete[] grafo;
    }

    void insereAresta(int v1, int v2) {
        if (v1 < 0 || v1 >= numeroVertices || v2 < 0 || v2 >= numeroVertices) {
            throw std::out_of_range("Índice de vértice fora do intervalo");
        }
        Item item(v2);  // Supondo que Item tem um construtor que aceita um int
        grafo[v1].push_back(item);  // Adiciona item ao Vetor na posição v1
    }

    void setCor(int vertice, int cor) {
        if (vertice < 0 || vertice >= numeroVertices) {
            throw std::out_of_range("Índice de vértice fora do intervalo");
        }
        vertices[vertice].valor = cor;
    }

    Vetor* getGrafo() {
        return grafo;
    }

    // Vetor& getCores() {
    //     return cores;
    // }

    Vetor& getVertices() {
        return vertices;
    }

    int getNumeroVertices() const {
        return numeroVertices;
    }

private:
    int numeroVertices;
    Vetor* grafo; // Array de Vetor para as listas de adjacências
    Vetor vertices; // Vértices do grafo
};

#endif
