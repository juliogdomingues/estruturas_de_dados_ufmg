#ifndef TP2_ED_VETOR_HPP
#define TP2_ED_VETOR_HPP

#include "../include/item.hpp"

#include <iostream>
#include <stdexcept>

class Vetor {
private:
    size_t capacity;
    size_t size;
    Item* array;

    void resize() {
        capacity = capacity * 2;
        Item* newArray = new Item[capacity];
        for (size_t i = 0; i < size; ++i) {
            newArray[i] = array[i];
        }
        // std::cout << "liberando array resize " << array;
        delete[] array;
        array = newArray;
    }

public:
    Vetor() : capacity(10), size(0), array(new Item[capacity]) {}

    Vetor(size_t initialCapacity) : capacity(initialCapacity), size(0), array(new Item[initialCapacity]) {}

    ~Vetor() {
        // std::cout << "liberando vetor " << array << std::endl;
        delete[] array;
        // std::cout << "done vetor " << array << std::endl;
    }

    void push_back(Item value) {
        if (size == capacity) {
            resize();
        }
        array[size++].chave = value.chave;
    }

    Item& operator[](size_t index) {
        if (index >= size) {
            throw std::out_of_range("Index out of range");
        }
        return array[index];
    }

    size_t getSize() const {
        return size;
    }

    Item* getArray() {
        return array;
    }
};

#endif
