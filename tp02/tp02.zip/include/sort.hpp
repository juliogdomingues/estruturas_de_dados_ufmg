#ifndef TP2_ED_SORT_HPP
#define TP2_ED_SORT_HPP

#include "../include/item.hpp"
#include "../include/grafo.hpp"
#include "../include/vetor.hpp"

#define Troca(A, B) {Item c = A; A = B; B = c; }

class Ordenacao {
public:
//    Ordenacao(Vetor *g, int n) : grafo(g), numeroVertices(n) {}
    void Bolha (Item *v, int n);
    void Insercao(Item *v, int n);
    void Selecao (Item *v, int n);

    void Particao(int Esq, int Dir, 
			  int *i, int *j, Item *A);
    void OrdenaQuick(int Esq, int Dir, Item *A);
    void QuickSort(Item *A, int n);

    Item *merge(Item *valuesL, Item *valuesR, int nl, int nr);
    void mergeSortAux(Item *arr, int left, int right);
    void mergeSort(Item *arr, int n);

    void Constroi(Item *A, int n);
    void Refaz(int Esq, int Dir, Item *A);
    Item RetiraMax(Item *A, int *n);
    void Heapsort(Item *A, int n);

    void MySort(Item *v, int n) {};

    Ordenacao(Grafo *g) : grafo(g) {}
    
   void Ordena(char metodo) {
    //   std::cout << "ordenacao " << metodo << std::endl;
      switch (metodo) {
            case 'b':
                Bolha(grafo->getVertices().getArray(), grafo->getNumeroVertices());
                break;
            case 's':
                Selecao(grafo->getVertices().getArray(), grafo->getNumeroVertices());
                break;
            case 'i':
                Insercao(grafo->getVertices().getArray(), grafo->getNumeroVertices());
                break;
            case 'q':
                QuickSort(grafo->getVertices().getArray(), grafo->getNumeroVertices());
                break;
            case 'm':
                mergeSort(grafo->getVertices().getArray(), grafo->getNumeroVertices());
                break;
            case 'p':
                Heapsort(grafo->getVertices().getArray(), grafo->getNumeroVertices());
                break;
            case 'y':
                // Implementação de MySort, se aplicável
                MySort(grafo->getVertices().getArray(), grafo->getNumeroVertices());
                break;
            default:
                std::cerr << "Método de ordenação desconhecido." << std::endl;
                break;
        }
    }

private:
    Grafo *grafo;
//     Vetor *grafo;
//    int numeroVertices;
};



#endif
