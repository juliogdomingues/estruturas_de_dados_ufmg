#include <algorithm>
#include <cassert>
#include <cstring>
#include <getopt.h>
#include <iostream>
#include <stdexcept>

#include "../include/sort.hpp"
#include "../include/item.hpp"

int Greedy(Vetor grafo[], Vetor& vertices, int n) {
    for (int i = 0; i < n; ++i) {
        if (i >= vertices.getSize()) {
            std::cerr << "Erro: Índice i (" << i << ") fora dos limites para cores.\n";
            throw std::out_of_range("Índice i fora dos limites para cores");
        }
        int corAtual = vertices[i].valor;
        // std::cout << "Verificando vértice " << i << " com cor " << corAtual << std::endl;

        for (int c = 1; c < corAtual; c++) {
            bool existeCorVizinha = false;
            for (int j = 0; j < grafo[i].getSize(); ++j) {
                int indiceVizinho = grafo[i][j].chave;
                if (indiceVizinho >= vertices.getSize()) {
                    std::cerr << "Erro: Índice indiceVizinho (" << indiceVizinho << ") fora dos limites para cores.\n";
                    throw std::out_of_range("Índice indiceVizinho fora dos limites para cores");
                }
                // std::cout << "  Vizinho " << indiceVizinho << " com cor " << vertices[indiceVizinho].valor << std::endl;

                if (vertices[indiceVizinho].valor == c) existeCorVizinha = true;
            }
            if  (!existeCorVizinha) {
                // std::cout << "  Coloração não gulosa encontrada!" << std::endl;
                return 0;
            }
        }
        // for (int j = 0; j < grafo[i].getSize(); ++j) {
        //     int indiceVizinho = grafo[i][j].chave;
        //     if (indiceVizinho >= vertices.getSize()) {
        //         std::cerr << "Erro: Índice indiceVizinho (" << indiceVizinho << ") fora dos limites para cores.\n";
        //         throw std::out_of_range("Índice indiceVizinho fora dos limites para cores");
        //     }
        //     std::cout << "  Vizinho " << indiceVizinho << " com cor " << cores[indiceVizinho].chave << std::endl;

        //     if (corAtual == vertices[indiceVizinho].valor) {
        //         std::cout << "  Coloração não gulosa encontrada!" << std::endl;
        //         return 0; 
        //     }
        // }
    }
    return 1;
}

int main() {

    // std::cout << "Iniciando o programa..." << std::endl;
    char metodo;
    int n;
    int max = 0;

    // std::cout << "Lendo método e número de vértices..." << std::endl;
    std::cin >> metodo >> n;
    // std::cout << "Método: " << metodo << ", Número de vértices: " << n << std::endl;

    // std::cout << "Construindo o grafo..." << std::endl;
    Grafo *grafo = new Grafo(n); // Cria um novo objeto Grafo
    // std::cout << "Grafo construído." << std::endl;

    for (int i = 0; i < n; i++) {
        // std::cout << "Lendo vizinhos do vértice " << i << std::endl;
        int numeroVizinhos, adjacente;
        std::cin >> numeroVizinhos;

        for (int j = 0; j < numeroVizinhos; j++) {
            std::cin >> adjacente;
            // std::cout << "  Inserindo aresta " << i << " -> " << adjacente << std::endl;
            grafo->insereAresta(i, adjacente);
        }
    }
    // std::cout << "Fim cria grafo" << std::endl;

    for (int i = 0; i < n; i++) {
        int corVertice;
        std::cin >> corVertice;
        // std::cout << "  Colorindo vertice " << i << " cor " << corVertice << std::endl;
        grafo->setCor(i, corVertice); // Define a cor de cada vértice
        if (corVertice > max) max = corVertice;
    }

    Ordenacao ordenacao(grafo); // Cria um objeto Ordenacao

    // Antes da ordenação
    // std::cout << "Vértices antes da ordenação: ";
    Vetor& vertices = grafo->getVertices(); // Obtém os vértices do grafo
    for (int i = 0; i < vertices.getSize(); ++i) {
        // std::cout << vertices[i].chave << " (" << vertices[i].valor << ")" << std::endl;
    }
    // std::cout << std::endl;

    // Verifica se a coloração é gulosa
    int resultadoColoracao = Greedy(grafo->getGrafo(), grafo->getVertices(), n);

    // Imprime o resultado da verificação
    if (resultadoColoracao == 0) {
        std::cout << "0" << std::endl;
    } else {
        std::cout << "1 ";
        ordenacao.Ordena(metodo); // Ordena os vértices

        for (int i = 0; i < vertices.getSize(); ++i) {
            std::cout << vertices[i].chave << " ";
        }
        std::cout << std::endl;

    }

    // std::cout << "liberando grafo main " << grafo << std::endl;
    delete grafo; // Liberar a memória alocada

    return 0;
}